import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Home, Search } from "lucide-react";
import { motion } from "motion/react";

export function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <Card className="p-12 text-center border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="text-8xl font-bold text-primary mb-4">404</div>
          <h1 className="text-3xl font-bold mb-2">Page Not Found</h1>
          <p className="text-muted-foreground mb-8">
            Oops! The page you're looking for doesn't exist. It might have been moved or deleted.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/">
              <Button size="lg" className="rounded-full">
                <Home className="mr-2 w-4 h-4" />
                Go Home
              </Button>
            </Link>
            <Link to="/learning-paths">
              <Button size="lg" variant="outline" className="rounded-full">
                <Search className="mr-2 w-4 h-4" />
                Browse Courses
              </Button>
            </Link>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
