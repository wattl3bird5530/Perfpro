import { Link } from "react-router";
import { useUserProgress } from "../contexts/UserProgressContext";
import coursesData from "../data/courses.json";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { Progress } from "../components/ui/progress";
import { motion } from "motion/react";
import {
  User,
  Award,
  BookOpen,
  Flame,
  Star,
  Calendar,
  Bookmark,
  StickyNote,
  TrendingUp,
  CheckCircle2,
} from "lucide-react";

export function Profile() {
  const { progress, isBookmarked } = useUserProgress();

  const totalLessons = coursesData.modules.reduce(
    (acc, module) => acc + module.lessons.length,
    0
  );
  const completedPercentage = Math.round(
    (progress.completedLessons.length / totalLessons) * 100
  );

  const bookmarkedLessons = coursesData.modules
    .flatMap((module) =>
      module.lessons
        .filter((lesson) => isBookmarked(lesson.id))
        .map((lesson) => ({ ...lesson, moduleId: module.id, moduleTitle: module.title }))
    )
    .slice(0, 5);

  const recentCompletions = progress.completedLessons
    .slice(-5)
    .reverse()
    .map((lessonId) => {
      const module = coursesData.modules.find((m) =>
        m.lessons.some((l) => l.id === lessonId)
      );
      const lesson = module?.lessons.find((l) => l.id === lessonId);
      return { lesson, module };
    })
    .filter((item) => item.lesson && item.module);

  const badges = [
    {
      name: "Fast Learner",
      description: "Complete 5 lessons in one day",
      earned: progress.completedLessons.length >= 5,
      icon: "⚡",
    },
    {
      name: "Dedicated Student",
      description: "Maintain a 7-day streak",
      earned: progress.streak >= 7,
      icon: "🔥",
    },
    {
      name: "Quiz Master",
      description: "Score 100% on any quiz",
      earned: Object.values(progress.quizScores).some((score) => score === 100),
      icon: "🎯",
    },
    {
      name: "Note Taker",
      description: "Write 10 notes",
      earned: Object.keys(progress.notes).length >= 10,
      icon: "📝",
    },
    {
      name: "Bookworm",
      description: "Bookmark 5 lessons",
      earned: progress.bookmarks.length >= 5,
      icon: "📚",
    },
    {
      name: "Champion",
      description: "Complete all modules",
      earned: completedPercentage === 100,
      icon: "🏆",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="p-8 border-border/40 bg-gradient-to-br from-primary/10 to-purple-500/10">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <Avatar className="w-24 h-24 border-4 border-primary">
              <AvatarFallback className="text-3xl font-bold bg-gradient-to-br from-primary to-purple-500 text-primary-foreground">
                <User className="w-12 h-12" />
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold mb-2">Your Profile</h1>
              <p className="text-muted-foreground mb-4">
                Digital Marketing Enthusiast
              </p>

              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <Badge variant="outline" className="text-sm">
                  <Star className="w-3 h-3 mr-1 text-yellow-500" />
                  {progress.score.toLocaleString()} Points
                </Badge>
                <Badge variant="outline" className="text-sm">
                  <Flame className="w-3 h-3 mr-1 text-orange-500" />
                  {progress.streak} Day Streak
                </Badge>
                <Badge variant="outline" className="text-sm">
                  <CheckCircle2 className="w-3 h-3 mr-1 text-green-500" />
                  {progress.completedLessons.length} Lessons
                </Badge>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: "Lessons Completed",
            value: `${progress.completedLessons.length}/${totalLessons}`,
            icon: BookOpen,
            color: "text-blue-500",
            bg: "bg-blue-500/10",
          },
          {
            label: "Quizzes Passed",
            value: Object.keys(progress.quizScores).length,
            icon: Award,
            color: "text-purple-500",
            bg: "bg-purple-500/10",
          },
          {
            label: "Bookmarks",
            value: progress.bookmarks.length,
            icon: Bookmark,
            color: "text-yellow-500",
            bg: "bg-yellow-500/10",
          },
          {
            label: "Notes Written",
            value: Object.keys(progress.notes).length,
            icon: StickyNote,
            color: "text-green-500",
            bg: "bg-green-500/10",
          },
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
                <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <div className="text-3xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Learning Progress */}
      <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold">Learning Progress</h2>
        </div>
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-2">
            <span>Overall Completion</span>
            <span className="font-bold">{completedPercentage}%</span>
          </div>
          <Progress value={completedPercentage} className="h-3" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          {coursesData.modules.map((module) => {
            const moduleCompleted = module.lessons.filter((l) =>
              progress.completedLessons.includes(l.id)
            ).length;
            const modulePercentage = Math.round(
              (moduleCompleted / module.lessons.length) * 100
            );

            return (
              <div key={module.id} className="p-4 rounded-xl bg-accent">
                <h3 className="font-semibold text-sm mb-2">{module.title}</h3>
                <Progress value={modulePercentage} className="h-2 mb-2" />
                <p className="text-xs text-muted-foreground">
                  {moduleCompleted}/{module.lessons.length} lessons
                </p>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Achievements */}
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold">Achievements</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {badges.map((badge, index) => (
              <motion.div
                key={badge.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`p-4 rounded-xl text-center transition-all ${
                  badge.earned
                    ? "bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-2 border-yellow-500/30"
                    : "bg-muted/30 opacity-50"
                }`}
              >
                <div className="text-3xl mb-2">{badge.icon}</div>
                <h3 className="font-semibold text-sm mb-1">{badge.name}</h3>
                <p className="text-xs text-muted-foreground">{badge.description}</p>
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold">Recent Completions</h2>
          </div>
          {recentCompletions.length > 0 ? (
            <div className="space-y-3">
              {recentCompletions.map((item: any, index) => (
                <Link
                  key={index}
                  to={`/lesson/${item.module.id}/${item.lesson.id}`}
                  className="block"
                >
                  <div className="p-3 rounded-lg bg-accent hover:bg-accent/70 transition-colors">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <h3 className="font-semibold text-sm">{item.lesson.title}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {item.module.title}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No completed lessons yet</p>
            </div>
          )}
        </Card>
      </div>

      {/* Bookmarked Lessons */}
      {bookmarkedLessons.length > 0 && (
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-4">
            <Bookmark className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold">Bookmarked Lessons</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {bookmarkedLessons.map((lesson: any) => (
              <Link
                key={lesson.id}
                to={`/lesson/${lesson.moduleId}/${lesson.id}`}
                className="block"
              >
                <div className="p-4 rounded-xl bg-accent hover:bg-accent/70 transition-colors border border-border/40">
                  <h3 className="font-semibold mb-1">{lesson.title}</h3>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-xs">
                      {lesson.moduleTitle}
                    </Badge>
                    <span>{lesson.duration}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
