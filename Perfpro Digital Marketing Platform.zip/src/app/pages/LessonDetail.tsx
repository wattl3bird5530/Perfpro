import { useParams, Link, useNavigate } from "react-router";
import { useState } from "react";
import { useUserProgress } from "../contexts/UserProgressContext";
import coursesData from "../data/courses.json";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Textarea } from "../components/ui/textarea";
import { motion } from "motion/react";
import {
  Bookmark,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  AlertTriangle,
  Sparkles,
  Keyboard,
  Target,
  PlayCircle,
  StickyNote,
  X,
} from "lucide-react";
import { toast } from "sonner";

export function LessonDetail() {
  const { moduleId, lessonId } = useParams();
  const navigate = useNavigate();
  const {
    completeLesson,
    toggleBookmark,
    saveNote,
    getNote,
    isBookmarked,
    isCompleted,
  } = useUserProgress();

  const [noteText, setNoteText] = useState("");
  const [showNotes, setShowNotes] = useState(false);

  const module = coursesData.modules.find((m) => m.id === moduleId);
  const lesson = module?.lessons.find((l) => l.id === lessonId);

  if (!module || !lesson) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Lesson not found</h2>
        <Link to="/learning-paths">
          <Button>Back to Learning Paths</Button>
        </Link>
      </div>
    );
  }

  const currentIndex = module.lessons.findIndex((l) => l.id === lessonId);
  const prevLesson = currentIndex > 0 ? module.lessons[currentIndex - 1] : null;
  const nextLesson =
    currentIndex < module.lessons.length - 1 ? module.lessons[currentIndex + 1] : null;

  const completed = isCompleted(lesson.id);
  const bookmarked = isBookmarked(lesson.id);
  const savedNote = getNote(lesson.id);

  const handleComplete = () => {
    completeLesson(lesson.id);
    toast.success("Lesson completed! +100 points", {
      description: "Keep up the great work!",
    });
  };

  const handleSaveNote = () => {
    saveNote(lesson.id, noteText);
    toast.success("Note saved!");
    setNoteText("");
  };

  const handleBookmark = () => {
    toggleBookmark(lesson.id);
    toast.success(bookmarked ? "Bookmark removed" : "Lesson bookmarked!");
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Link to="/learning-paths" className="hover:text-foreground transition-colors">
          Learning Paths
        </Link>
        <span>/</span>
        <span className="text-foreground font-medium">{module.title}</span>
      </div>

      {/* Lesson Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <Badge variant="outline" className="mb-3">
                Lesson {currentIndex + 1} of {module.lessons.length}
              </Badge>
              <h1 className="text-3xl font-bold mb-2">{lesson.title}</h1>
              <p className="text-muted-foreground">{lesson.description}</p>
            </div>
            <div className="flex gap-2">
              <Button
                variant={bookmarked ? "default" : "outline"}
                size="icon"
                onClick={handleBookmark}
                className="rounded-full"
              >
                <Bookmark className={`w-4 h-4 ${bookmarked ? "fill-current" : ""}`} />
              </Button>
              {!completed && (
                <Button onClick={handleComplete} className="rounded-full">
                  <CheckCircle2 className="mr-2 w-4 h-4" />
                  Mark Complete
                </Button>
              )}
              {completed && (
                <Badge variant="outline" className="bg-green-500/10 text-green-500">
                  <CheckCircle2 className="mr-2 w-4 h-4" />
                  Completed
                </Badge>
              )}
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Video Section */}
      <Card className="overflow-hidden border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="aspect-video bg-black relative group">
          <iframe
            width="100%"
            height="100%"
            src={`https://www.youtube.com/embed/${lesson.videoId}`}
            title={lesson.title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          />
          <div className="absolute top-4 left-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <Badge variant="secondary" className="backdrop-blur-sm">
              <PlayCircle className="w-3 h-3 mr-1" />
              {lesson.duration}
            </Badge>
          </div>
        </div>
      </Card>

      {/* Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Explanation */}
        <Card className="p-6 border-border/40 bg-gradient-to-br from-blue-500/5 to-purple-500/5">
          <div className="flex items-center gap-2 mb-4">
            <Lightbulb className="w-5 h-5 text-blue-500" />
            <h2 className="text-xl font-bold">Simple Explanation</h2>
          </div>
          <p className="text-sm leading-relaxed">{lesson.content.explanation}</p>
        </Card>

        {/* Real World Example */}
        <Card className="p-6 border-border/40 bg-gradient-to-br from-green-500/5 to-emerald-500/5">
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-green-500" />
            <h2 className="text-xl font-bold">Real-World Example</h2>
          </div>
          <p className="text-sm leading-relaxed">{lesson.content.realWorldExample}</p>
        </Card>
      </div>

      {/* Platform Shortcuts */}
      <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex items-center gap-2 mb-4">
          <Keyboard className="w-5 h-5 text-purple-500" />
          <h2 className="text-xl font-bold">Platform Shortcuts & Tips</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {lesson.content.platformShortcuts.map((shortcut, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20"
            >
              <p className="text-sm">{shortcut}</p>
            </motion.div>
          ))}
        </div>
      </Card>

      {/* Key Takeaways */}
      <Card className="p-6 border-border/40 bg-gradient-to-br from-yellow-500/5 to-orange-500/5">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-yellow-500" />
          <h2 className="text-xl font-bold">Key Takeaways</h2>
        </div>
        <ul className="space-y-2">
          {lesson.content.keyTakeaways.map((takeaway, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-3"
            >
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-sm">{takeaway}</span>
            </motion.li>
          ))}
        </ul>
      </Card>

      {/* Mistakes to Avoid */}
      <Card className="p-6 border-border/40 bg-gradient-to-br from-red-500/5 to-pink-500/5">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <h2 className="text-xl font-bold">Common Mistakes to Avoid</h2>
        </div>
        <ul className="space-y-2">
          {lesson.content.mistakesToAvoid.map((mistake, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-3"
            >
              <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <span className="text-sm">{mistake}</span>
            </motion.li>
          ))}
        </ul>
      </Card>

      {/* Pro Tips */}
      <Card className="p-6 border-border/40 bg-gradient-to-br from-cyan-500/5 to-blue-500/5">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-cyan-500" />
          <h2 className="text-xl font-bold">Pro Tips</h2>
        </div>
        <div className="space-y-3">
          {lesson.content.proTips.map((tip, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20"
            >
              <p className="text-sm font-medium">{tip}</p>
            </motion.div>
          ))}
        </div>
      </Card>

      {/* Notes Section */}
      <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <StickyNote className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold">Your Notes</h2>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowNotes(!showNotes)}
          >
            {showNotes ? "Hide" : "Show"} Notes
          </Button>
        </div>

        {showNotes && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-3"
          >
            {savedNote && (
              <div className="p-4 rounded-xl bg-accent">
                <p className="text-sm whitespace-pre-wrap">{savedNote}</p>
              </div>
            )}
            <Textarea
              placeholder="Write your notes here..."
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              className="min-h-[120px]"
            />
            <Button onClick={handleSaveNote} disabled={!noteText.trim()}>
              Save Note
            </Button>
          </motion.div>
        )}
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center">
        {prevLesson ? (
          <Button
            variant="outline"
            onClick={() => navigate(`/lesson/${moduleId}/${prevLesson.id}`)}
            className="rounded-full"
          >
            <ChevronLeft className="mr-2 w-4 h-4" />
            Previous Lesson
          </Button>
        ) : (
          <div />
        )}

        {nextLesson ? (
          <Button
            onClick={() => navigate(`/lesson/${moduleId}/${nextLesson.id}`)}
            className="rounded-full"
          >
            Next Lesson
            <ChevronRight className="ml-2 w-4 h-4" />
          </Button>
        ) : (
          <Link to={`/quiz/${moduleId}`}>
            <Button className="rounded-full">
              Take Quiz
              <ChevronRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}
