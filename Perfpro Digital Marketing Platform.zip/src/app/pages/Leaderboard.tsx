import { useUserProgress } from "../contexts/UserProgressContext";
import leaderboardData from "../data/leaderboard.json";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { motion } from "motion/react";
import { Trophy, Medal, Crown, TrendingUp, Zap } from "lucide-react";

export function Leaderboard() {
  const { progress } = useUserProgress();

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-orange-500" />;
    return null;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return "from-yellow-500/20 to-orange-500/20 border-yellow-500/30";
    if (rank === 2) return "from-gray-400/20 to-gray-500/20 border-gray-400/30";
    if (rank === 3) return "from-orange-500/20 to-red-500/20 border-orange-500/30";
    return "from-card/50 to-card/30";
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 mb-4">
          <Trophy className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold mb-2">Leaderboard</h1>
        <p className="text-muted-foreground text-lg">
          Compete with learners worldwide and climb to the top!
        </p>
      </motion.div>

      {/* Your Rank Card */}
      <Card className="p-6 border-primary/40 bg-gradient-to-br from-primary/10 to-purple-500/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 border-2 border-primary">
              <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">
                YOU
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-xl font-bold mb-1">Your Progress</h3>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  <Zap className="w-3 h-3 mr-1" />
                  {progress.score.toLocaleString()} points
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {progress.streak} day streak
                </Badge>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary">
              #{leaderboardData.users.findIndex(u => u.score <= progress.score) + 1}
            </div>
            <div className="text-xs text-muted-foreground">Your Rank</div>
          </div>
        </div>
      </Card>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {[1, 0, 2].map((index) => {
          const user = leaderboardData.users[index];
          const rank = index + 1;
          const actualRank = index === 1 ? 1 : index === 0 ? 2 : 3;

          return (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: actualRank * 0.1 }}
              className={`text-center ${actualRank === 2 ? "order-first" : ""}`}
            >
              <Card
                className={`p-6 border-border/40 bg-gradient-to-br ${getRankColor(
                  actualRank
                )}`}
              >
                <div className="relative mb-4">
                  <Avatar className={`w-20 h-20 mx-auto border-4 ${
                    actualRank === 1 ? "border-yellow-500" :
                    actualRank === 2 ? "border-gray-400" :
                    "border-orange-500"
                  }`}>
                    <AvatarFallback className="text-xl font-bold">
                      {user.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                    {getRankIcon(actualRank)}
                  </div>
                </div>
                <h3 className="font-bold mb-1">{user.name}</h3>
                <p className="text-2xl font-bold text-primary mb-2">
                  {user.score.toLocaleString()}
                </p>
                <Badge variant="outline" className="text-xs">
                  {user.level}
                </Badge>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Full Leaderboard */}
      <Card className="border-border/40 bg-card/50 backdrop-blur-sm overflow-hidden">
        <div className="p-6 border-b border-border/40">
          <h2 className="text-xl font-bold">All Rankings</h2>
        </div>
        <div className="divide-y divide-border/40">
          {leaderboardData.users.map((user, index) => (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-4 hover:bg-accent/50 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 text-center">
                  {index < 3 ? (
                    <div className="inline-flex">{getRankIcon(index + 1)}</div>
                  ) : (
                    <span className="text-lg font-bold text-muted-foreground">
                      #{index + 1}
                    </span>
                  )}
                </div>

                <Avatar className="w-12 h-12 border-2 border-border">
                  <AvatarFallback className="font-bold">{user.avatar}</AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold mb-1">{user.name}</h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-xs">
                      {user.level}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {user.completedModules} modules • {user.streak} day streak
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xl font-bold">
                    {user.score.toLocaleString()}
                  </div>
                  <div className="text-xs text-muted-foreground">points</div>
                </div>

                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>

              {user.badges.length > 0 && (
                <div className="ml-16 mt-3 flex items-center gap-2 flex-wrap">
                  {user.badges.slice(0, 3).map((badge) => (
                    <Badge key={badge} variant="secondary" className="text-xs">
                      {badge}
                    </Badge>
                  ))}
                  {user.badges.length > 3 && (
                    <span className="text-xs text-muted-foreground">
                      +{user.badges.length - 3} more
                    </span>
                  )}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 text-center border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="text-3xl font-bold mb-1">
            {leaderboardData.users.length}
          </div>
          <div className="text-sm text-muted-foreground">Total Learners</div>
        </Card>
        <Card className="p-6 text-center border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="text-3xl font-bold mb-1">
            {Math.round(
              leaderboardData.users.reduce((acc, u) => acc + u.streak, 0) /
                leaderboardData.users.length
            )}
          </div>
          <div className="text-sm text-muted-foreground">Avg. Streak (days)</div>
        </Card>
        <Card className="p-6 text-center border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="text-3xl font-bold mb-1">
            {leaderboardData.users.reduce((acc, u) => acc + u.completedModules, 0)}
          </div>
          <div className="text-sm text-muted-foreground">Total Completions</div>
        </Card>
      </div>
    </div>
  );
}
