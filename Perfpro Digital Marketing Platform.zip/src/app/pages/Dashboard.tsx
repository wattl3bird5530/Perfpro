import { Link } from "react-router";
import { useUserProgress } from "../contexts/UserProgressContext";
import coursesData from "../data/courses.json";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { motion } from "motion/react";
import {
  Flame,
  Target,
  BookOpen,
  TrendingUp,
  Clock,
  CheckCircle2,
  ArrowRight,
  Zap,
  Star,
} from "lucide-react";

export function Dashboard() {
  const { progress } = useUserProgress();

  const totalLessons = coursesData.modules.reduce(
    (acc, module) => acc + module.lessons.length,
    0
  );
  const completedPercentage = Math.round(
    (progress.completedLessons.length / totalLessons) * 100
  );

  const recentModules = coursesData.modules.slice(0, 3);

  const stats = [
    {
      label: "Current Streak",
      value: `${progress.streak} days`,
      icon: Flame,
      color: "text-orange-500",
      bg: "bg-orange-500/10",
    },
    {
      label: "Total Score",
      value: progress.score.toLocaleString(),
      icon: Star,
      color: "text-yellow-500",
      bg: "bg-yellow-500/10",
    },
    {
      label: "Completed",
      value: `${progress.completedLessons.length}/${totalLessons}`,
      icon: CheckCircle2,
      color: "text-green-500",
      bg: "bg-green-500/10",
    },
    {
      label: "Modules Done",
      value: Object.keys(progress.quizScores).length,
      icon: Target,
      color: "text-blue-500",
      bg: "bg-blue-500/10",
    },
  ];

  const dailyTasks = [
    { id: 1, task: "Complete one lesson", completed: progress.completedLessons.length > 0 },
    { id: 2, task: "Take a quiz", completed: Object.keys(progress.quizScores).length > 0 },
    { id: 3, task: "Add a bookmark", completed: progress.bookmarks.length > 0 },
    { id: 4, task: "Write a note", completed: Object.keys(progress.notes).length > 0 },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 p-8 border border-border/40"
      >
        <div className="absolute inset-0 bg-grid-white/5 [mask-image:linear-gradient(0deg,transparent,black)]" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-6 h-6 text-yellow-500" />
            <Badge variant="secondary" className="text-xs">Welcome back!</Badge>
          </div>
          <h1 className="text-4xl font-bold mb-2">
            Master Digital Marketing, One Lesson at a Time
          </h1>
          <p className="text-muted-foreground text-lg mb-6">
            Transform your skills with practical, real-world advertising strategies
          </p>
          <div className="flex flex-wrap gap-3">
            <Link to="/learning-paths">
              <Button size="lg" className="rounded-full">
                Continue Learning <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link to="/simulator">
              <Button size="lg" variant="outline" className="rounded-full">
                Try Campaign Simulator
              </Button>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 hover:shadow-lg transition-shadow border-border/40 bg-card/50 backdrop-blur-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-3 rounded-xl ${stat.bg}`}>
                    <Icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </div>
                <div className="text-3xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Progress Overview */}
      <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold mb-1">Your Progress</h2>
            <p className="text-sm text-muted-foreground">
              {completedPercentage}% complete - Keep going!
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{completedPercentage}%</div>
          </div>
        </div>
        <Progress value={completedPercentage} className="h-3 mb-4" />
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <BookOpen className="w-4 h-4" />
          <span>
            {progress.completedLessons.length} of {totalLessons} lessons completed
          </span>
        </div>
      </Card>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Tasks */}
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold">Daily Tasks</h2>
          </div>
          <div className="space-y-3">
            {dailyTasks.map((task) => (
              <motion.div
                key={task.id}
                whileHover={{ x: 4 }}
                className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  task.completed ? "bg-green-500/10" : "bg-accent"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    task.completed
                      ? "border-green-500 bg-green-500"
                      : "border-muted-foreground"
                  }`}
                >
                  {task.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                </div>
                <span
                  className={`text-sm ${
                    task.completed ? "line-through text-muted-foreground" : ""
                  }`}
                >
                  {task.task}
                </span>
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Continue Learning */}
        <Card className="lg:col-span-2 p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-bold">Continue Learning</h2>
            </div>
            <Link to="/learning-paths">
              <Button variant="ghost" size="sm">
                View All <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
          <div className="space-y-4">
            {recentModules.map((module, index) => (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={`/lesson/${module.id}/${module.lessons[0].id}`}>
                  <div className="group flex items-center gap-4 p-4 rounded-xl hover:bg-accent transition-all cursor-pointer border border-transparent hover:border-border/40">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        module.level === "beginner"
                          ? "bg-green-500/10 text-green-500"
                          : module.level === "intermediate"
                          ? "bg-blue-500/10 text-blue-500"
                          : "bg-purple-500/10 text-purple-500"
                      }`}
                    >
                      <BookOpen className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold mb-1 group-hover:text-primary transition-colors">
                        {module.title}
                      </h3>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <Badge variant="outline" className="capitalize">
                          {module.level}
                        </Badge>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {module.duration}
                        </span>
                      </div>
                    </div>
                    <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
