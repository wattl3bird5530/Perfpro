import { Link } from "react-router";
import { useState } from "react";
import { useUserProgress } from "../contexts/UserProgressContext";
import coursesData from "../data/courses.json";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { motion } from "motion/react";
import {
  BookOpen,
  Clock,
  CheckCircle2,
  Lock,
  Play,
  Award,
  Filter,
} from "lucide-react";

export function LearningPaths() {
  const { progress, isCompleted } = useUserProgress();
  const [selectedLevel, setSelectedLevel] = useState<string>("all");

  const filteredModules =
    selectedLevel === "all"
      ? coursesData.modules
      : coursesData.modules.filter((m) => m.level === selectedLevel);

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-green-500/10 text-green-500 border-green-500/20";
      case "intermediate":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "advanced":
        return "bg-purple-500/10 text-purple-500 border-purple-500/20";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getModuleProgress = (moduleId: string) => {
    const module = coursesData.modules.find((m) => m.id === moduleId);
    if (!module) return 0;
    const completedCount = module.lessons.filter((l) => isCompleted(l.id)).length;
    return Math.round((completedCount / module.lessons.length) * 100);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl font-bold mb-2">Learning Paths</h1>
        <p className="text-muted-foreground text-lg">
          Structured courses from beginner to advanced level
        </p>
      </motion.div>

      {/* Filters */}
      <Card className="p-4 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium mr-2">Filter by level:</span>
          {["all", "beginner", "intermediate", "advanced"].map((level) => (
            <Button
              key={level}
              variant={selectedLevel === level ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedLevel(level)}
              className="capitalize rounded-full"
            >
              {level}
            </Button>
          ))}
        </div>
      </Card>

      {/* Modules Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredModules.map((module, index) => {
          const moduleProgress = getModuleProgress(module.id);
          const allLessonsCompleted =
            module.lessons.every((l) => isCompleted(l.id));

          return (
            <motion.div
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="group overflow-hidden border-border/40 bg-card/50 backdrop-blur-sm hover:shadow-xl transition-all">
                {/* Header Section */}
                <div className="p-6 border-b border-border/40">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center ${getLevelColor(
                        module.level
                      )}`}
                    >
                      <BookOpen className="w-7 h-7" />
                    </div>
                    <Badge
                      variant="outline"
                      className={`capitalize ${getLevelColor(module.level)}`}
                    >
                      {module.level}
                    </Badge>
                  </div>
                  <h2 className="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">
                    {module.title}
                  </h2>
                  <p className="text-muted-foreground text-sm mb-4">
                    {module.description}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {module.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <BookOpen className="w-4 h-4" />
                      {module.lessons.length} lessons
                    </span>
                  </div>
                </div>

                {/* Progress Section */}
                <div className="p-6 bg-accent/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Progress</span>
                    <span className="text-sm font-bold">{moduleProgress}%</span>
                  </div>
                  <Progress value={moduleProgress} className="h-2 mb-4" />

                  {/* Lessons List */}
                  <div className="space-y-2 mb-4">
                    {module.lessons.slice(0, 3).map((lesson, idx) => {
                      const completed = isCompleted(lesson.id);
                      const isLocked = idx > 0 && !isCompleted(module.lessons[idx - 1].id);

                      return (
                        <div
                          key={lesson.id}
                          className={`flex items-center gap-3 p-2 rounded-lg ${
                            completed
                              ? "bg-green-500/10"
                              : isLocked
                              ? "bg-muted/30"
                              : "bg-background/50"
                          }`}
                        >
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              completed
                                ? "bg-green-500 text-white"
                                : isLocked
                                ? "bg-muted"
                                : "bg-primary/20"
                            }`}
                          >
                            {completed ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : isLocked ? (
                              <Lock className="w-3 h-3" />
                            ) : (
                              <Play className="w-3 h-3" />
                            )}
                          </div>
                          <span
                            className={`text-sm flex-1 ${
                              isLocked ? "text-muted-foreground" : ""
                            }`}
                          >
                            {lesson.title}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {lesson.duration}
                          </span>
                        </div>
                      );
                    })}
                    {module.lessons.length > 3 && (
                      <p className="text-xs text-muted-foreground text-center py-1">
                        +{module.lessons.length - 3} more lessons
                      </p>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Link
                      to={`/lesson/${module.id}/${module.lessons[0].id}`}
                      className="flex-1"
                    >
                      <Button className="w-full rounded-xl" size="lg">
                        {moduleProgress === 0 ? (
                          <>
                            <Play className="mr-2 w-4 h-4" />
                            Start Learning
                          </>
                        ) : moduleProgress === 100 ? (
                          <>
                            <Award className="mr-2 w-4 h-4" />
                            Review
                          </>
                        ) : (
                          <>Continue</>
                        )}
                      </Button>
                    </Link>
                    {allLessonsCompleted && (
                      <Link to={`/quiz/${module.id}`}>
                        <Button variant="outline" size="lg" className="rounded-xl">
                          <Award className="mr-2 w-4 h-4" />
                          Take Quiz
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filteredModules.length === 0 && (
        <Card className="p-12 text-center border-border/40 bg-card/50 backdrop-blur-sm">
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No modules found</h3>
          <p className="text-muted-foreground mb-4">
            Try selecting a different level filter
          </p>
          <Button onClick={() => setSelectedLevel("all")}>Show All Modules</Button>
        </Card>
      )}
    </div>
  );
}
