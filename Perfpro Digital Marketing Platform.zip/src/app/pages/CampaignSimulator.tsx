import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Textarea } from "../components/ui/textarea";
import { motion } from "motion/react";
import {
  Sparkles,
  TrendingUp,
  DollarSign,
  Users,
  Target,
  BarChart3,
  Play,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";

export function CampaignSimulator() {
  const [platform, setPlatform] = useState("meta");
  const [objective, setObjective] = useState("");
  const [budget, setBudget] = useState("");
  const [audience, setAudience] = useState("");
  const [adCopy, setAdCopy] = useState("");
  const [results, setResults] = useState<any>(null);

  const calculateResults = () => {
    if (!objective || !budget || !audience) {
      toast.error("Please fill in all required fields");
      return;
    }

    const budgetNum = parseFloat(budget);
    const baseCPC = platform === "meta" ? 0.8 : 1.2;
    const clicks = Math.round(budgetNum / baseCPC);
    const ctr = Math.random() * 2 + 1; // 1-3%
    const impressions = Math.round(clicks / (ctr / 100));
    const conversionRate = Math.random() * 3 + 1; // 1-4%
    const conversions = Math.round(clicks * (conversionRate / 100));
    const cpa = conversions > 0 ? (budgetNum / conversions).toFixed(2) : "0";

    setResults({
      impressions: impressions.toLocaleString(),
      clicks: clicks.toLocaleString(),
      ctr: ctr.toFixed(2),
      conversions,
      conversionRate: conversionRate.toFixed(2),
      cpa,
      roas: (Math.random() * 3 + 2).toFixed(2), // 2-5x
    });

    toast.success("Campaign simulation complete!");
  };

  const reset = () => {
    setObjective("");
    setBudget("");
    setAudience("");
    setAdCopy("");
    setResults(null);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold mb-2">Campaign Simulator</h1>
        <p className="text-muted-foreground text-lg">
          Build and test ad campaigns in a risk-free environment
        </p>
      </motion.div>

      <Tabs value={platform} onValueChange={setPlatform}>
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
          <TabsTrigger value="meta">Meta Ads</TabsTrigger>
          <TabsTrigger value="google">Google Ads</TabsTrigger>
        </TabsList>

        <TabsContent value={platform} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Configuration Panel */}
            <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Campaign Setup
              </h2>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="objective">Campaign Objective *</Label>
                  <Select value={objective} onValueChange={setObjective}>
                    <SelectTrigger id="objective">
                      <SelectValue placeholder="Select objective" />
                    </SelectTrigger>
                    <SelectContent>
                      {platform === "meta" ? (
                        <>
                          <SelectItem value="conversions">Conversions</SelectItem>
                          <SelectItem value="traffic">Traffic</SelectItem>
                          <SelectItem value="engagement">Engagement</SelectItem>
                          <SelectItem value="leads">Lead Generation</SelectItem>
                          <SelectItem value="awareness">Brand Awareness</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="search">Search</SelectItem>
                          <SelectItem value="shopping">Shopping</SelectItem>
                          <SelectItem value="display">Display</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="budget">Daily Budget ($) *</Label>
                  <Input
                    id="budget"
                    type="number"
                    placeholder="e.g., 50"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="audience">Target Audience *</Label>
                  <Select value={audience} onValueChange={setAudience}>
                    <SelectTrigger id="audience">
                      <SelectValue placeholder="Select audience" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="broad">Broad (18-65+)</SelectItem>
                      <SelectItem value="millennials">Millennials (25-40)</SelectItem>
                      <SelectItem value="genz">Gen Z (18-24)</SelectItem>
                      <SelectItem value="professionals">Professionals (30-50)</SelectItem>
                      <SelectItem value="seniors">Seniors (55+)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="adcopy">Ad Copy (Optional)</Label>
                  <Textarea
                    id="adcopy"
                    placeholder="Write your ad headline and description..."
                    value={adCopy}
                    onChange={(e) => setAdCopy(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                <div className="flex gap-2 pt-4">
                  <Button onClick={calculateResults} className="flex-1" size="lg">
                    <Play className="mr-2 w-4 h-4" />
                    Run Simulation
                  </Button>
                  <Button onClick={reset} variant="outline" size="lg">
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>

            {/* Results Panel */}
            <Card className="p-6 border-border/40 bg-gradient-to-br from-primary/5 to-purple-500/5">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-primary" />
                Predicted Results
              </h2>

              {results ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">
                        Impressions
                      </div>
                      <div className="text-2xl font-bold">{results.impressions}</div>
                    </div>
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">Clicks</div>
                      <div className="text-2xl font-bold">{results.clicks}</div>
                    </div>
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">CTR</div>
                      <div className="text-2xl font-bold">{results.ctr}%</div>
                    </div>
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">
                        Conversions
                      </div>
                      <div className="text-2xl font-bold">{results.conversions}</div>
                    </div>
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">CVR</div>
                      <div className="text-2xl font-bold">
                        {results.conversionRate}%
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-card/80 backdrop-blur-sm">
                      <div className="text-sm text-muted-foreground mb-1">CPA</div>
                      <div className="text-2xl font-bold">${results.cpa}</div>
                    </div>
                  </div>

                  <div className="p-6 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Est. ROAS</span>
                      <TrendingUp className="w-5 h-5 text-green-500" />
                    </div>
                    <div className="text-4xl font-bold text-green-500">
                      {results.roas}x
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      For every $1 spent, you earn ${results.roas}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-sm">Recommendations:</h3>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>
                          {parseFloat(results.ctr) < 2
                            ? "CTR is low - improve your ad creative or targeting"
                            : "Great CTR! Your ad is resonating with the audience"}
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>
                          {parseFloat(results.conversionRate) < 2
                            ? "Optimize landing page to improve conversion rate"
                            : "Excellent conversion rate - keep this campaign running"}
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>
                          Consider testing different audience segments for better results
                        </span>
                      </li>
                    </ul>
                  </div>
                </motion.div>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-center">
                  <div>
                    <BarChart3 className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Configure your campaign and click "Run Simulation" to see
                      predicted results
                    </p>
                  </div>
                </div>
              )}
            </Card>
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="font-semibold">Audience Insights</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Narrow targeting increases relevance but reduces reach. Test broad
                first, then refine.
              </p>
            </Card>

            <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-purple-500" />
                </div>
                <h3 className="font-semibold">Budget Optimization</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Start with $20-50/day minimum. Below that, algorithms can't learn
                effectively.
              </p>
            </Card>

            <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
                  <Target className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="font-semibold">Objective Selection</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Choose objective based on your goal: Conversions for sales, Traffic for
                awareness.
              </p>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
