import { useParams, useNavigate, Link } from "react-router";
import { useState } from "react";
import { useUserProgress } from "../contexts/UserProgressContext";
import quizzesData from "../data/quizzes.json";
import coursesData from "../data/courses.json";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { motion, AnimatePresence } from "motion/react";
import {
  CheckCircle2,
  XCircle,
  Award,
  Trophy,
  RotateCcw,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import confetti from "canvas-confetti";
import { toast } from "sonner";

export function QuizPage() {
  const { moduleId } = useParams();
  const navigate = useNavigate();
  const { saveQuizScore } = useUserProgress();

  const quiz = quizzesData.quizzes[moduleId as keyof typeof quizzesData.quizzes];
  const module = coursesData.modules.find((m) => m.id === moduleId);

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  if (!quiz || !module) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Quiz not found</h2>
        <Link to="/learning-paths">
          <Button>Back to Learning Paths</Button>
        </Link>
      </div>
    );
  }

  const question = quiz.questions[currentQuestion];
  const totalQuestions = quiz.questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResults) return;

    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    let correctCount = 0;
    quiz.questions.forEach((q, index) => {
      if (selectedAnswers[index] === q.correctAnswer) {
        correctCount++;
      }
    });

    const finalScore = Math.round((correctCount / totalQuestions) * 100);
    setScore(finalScore);
    setShowResults(true);
    saveQuizScore(moduleId!, finalScore);

    if (finalScore >= quiz.passingScore) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
      toast.success("Congratulations! You passed!", {
        description: `You scored ${finalScore}%`,
      });
    }
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setScore(0);
  };

  if (showResults) {
    const passed = score >= quiz.passingScore;
    const correctCount = Math.round((score / 100) * totalQuestions);

    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <Card className="p-8 text-center border-border/40 bg-card/50 backdrop-blur-sm">
            <div
              className={`w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center ${
                passed
                  ? "bg-green-500/20 text-green-500"
                  : "bg-yellow-500/20 text-yellow-500"
              }`}
            >
              {passed ? (
                <Trophy className="w-10 h-10" />
              ) : (
                <Award className="w-10 h-10" />
              )}
            </div>

            <h1 className="text-3xl font-bold mb-2">
              {passed ? "Excellent Work!" : "Good Effort!"}
            </h1>
            <p className="text-muted-foreground mb-6">
              You scored {score}% on {module.title}
            </p>

            <div className="max-w-md mx-auto mb-8">
              <div className="flex justify-between text-sm mb-2">
                <span>Your Score</span>
                <span className="font-bold">{score}%</span>
              </div>
              <Progress
                value={score}
                className="h-4"
              />
              <p className="text-xs text-muted-foreground mt-2">
                {correctCount} out of {totalQuestions} questions correct
              </p>
            </div>

            {passed ? (
              <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 mb-6">
                <p className="text-sm text-green-600 dark:text-green-400">
                  🎉 Congratulations! You've passed the quiz with {score}%. You've
                  earned +{score * 10} points!
                </p>
              </div>
            ) : (
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4 mb-6">
                <p className="text-sm text-yellow-600 dark:text-yellow-400">
                  You need {quiz.passingScore}% to pass. Review the lessons and try
                  again!
                </p>
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={handleRetry} size="lg" className="rounded-full">
                <RotateCcw className="mr-2 w-4 h-4" />
                Retry Quiz
              </Button>
              <Link to="/learning-paths">
                <Button size="lg" className="rounded-full">
                  Back to Learning Paths
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
            </div>
          </Card>
        </motion.div>

        {/* Review Answers */}
        <Card className="p-6 border-border/40 bg-card/50 backdrop-blur-sm">
          <h2 className="text-xl font-bold mb-4">Review Your Answers</h2>
          <div className="space-y-4">
            {quiz.questions.map((q, index) => {
              const userAnswer = selectedAnswers[index];
              const isCorrect = userAnswer === q.correctAnswer;

              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-xl border ${
                    isCorrect
                      ? "bg-green-500/10 border-green-500/20"
                      : "bg-red-500/10 border-red-500/20"
                  }`}
                >
                  <div className="flex items-start gap-3 mb-3">
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="font-semibold mb-2">
                        {index + 1}. {q.question}
                      </p>
                      {!isCorrect && (
                        <div className="text-sm space-y-1">
                          <p className="text-red-500">
                            Your answer: {q.options[userAnswer]}
                          </p>
                          <p className="text-green-500">
                            Correct answer: {q.options[q.correctAnswer]}
                          </p>
                        </div>
                      )}
                      <p className="text-sm text-muted-foreground mt-2">
                        {q.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">{quiz.title}</h1>
          <p className="text-sm text-muted-foreground">
            {module.title} • {totalQuestions} Questions
          </p>
        </div>
        <Badge variant="outline" className="text-sm">
          Question {currentQuestion + 1} of {totalQuestions}
        </Badge>
      </div>

      {/* Progress */}
      <Card className="p-4 border-border/40 bg-card/50 backdrop-blur-sm">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-medium">{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </Card>

      {/* Question Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="p-8 border-border/40 bg-gradient-to-br from-primary/5 to-purple-500/5">
            <div className="flex items-start gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold mb-2">{question.question}</h2>
                <p className="text-sm text-muted-foreground">
                  Select the best answer
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {question.options.map((option, index) => {
                const isSelected = selectedAnswers[currentQuestion] === index;

                return (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
                      isSelected
                        ? "border-primary bg-primary/10 shadow-lg shadow-primary/20"
                        : "border-border/40 bg-card/50 hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          isSelected
                            ? "border-primary bg-primary"
                            : "border-muted-foreground"
                        }`}
                      >
                        {isSelected && (
                          <CheckCircle2 className="w-4 h-4 text-primary-foreground" />
                        )}
                      </div>
                      <span className={isSelected ? "font-medium" : ""}>
                        {option}
                      </span>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
          disabled={currentQuestion === 0}
          className="rounded-full"
        >
          Previous
        </Button>
        <Button
          onClick={handleNext}
          disabled={selectedAnswers[currentQuestion] === undefined}
          className="rounded-full"
        >
          {currentQuestion === totalQuestions - 1 ? "Finish Quiz" : "Next Question"}
          <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
