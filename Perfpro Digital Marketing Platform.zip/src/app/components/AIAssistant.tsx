import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { motion, AnimatePresence } from "motion/react";
import { Bot, X, Send, Sparkles } from "lucide-react";
import { toast } from "sonner";

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([
    {
      role: "assistant",
      content: "Hi! I'm your AI learning assistant. Ask me anything about digital marketing!",
    },
  ]);
  const [input, setInput] = useState("");

  const predefinedResponses: Record<string, string> = {
    "meta ads": "Meta Ads (Facebook & Instagram) are great for visual products and building audiences. Start with the Conversions objective if you have conversion tracking set up, or Traffic objective if you're just starting out. Key tip: Let your ads run for at least 3-7 days before making changes to avoid resetting the learning phase.",
    "google ads": "Google Ads captures high-intent traffic through search. Use Search campaigns for immediate conversions, Shopping for e-commerce products. Start with Phrase match keywords and add Exact match for winners. Always use negative keywords to prevent wasted spend!",
    "pixel": "The Meta Pixel is crucial for tracking conversions. Install it on every page of your website, not just the landing page. Make sure to track standard events like Purchase, Lead, or AddToCart. Test it with the Meta Pixel Helper Chrome extension before launching campaigns.",
    "budget": "Start with at least $20-50/day for testing. Below that, algorithms can't learn effectively. For Meta, you need ~50 conversions per week per ad set for optimal performance. Increase budget by max 20% every 3-7 days to avoid disrupting the learning phase.",
    "targeting": "Broader targeting often works better than you think! Start with interest-based audiences on Meta. For Google, use In-Market audiences. Create lookalike audiences from your best customers. Test different audience segments in separate ad sets.",
    "roas": "ROAS (Return on Ad Spend) is revenue divided by ad spend. A 3x ROAS means $3 earned for every $1 spent. Good ROAS varies by industry: e-commerce aims for 3-5x, SaaS 2-3x, lead gen 4-6x. Focus on profitable ROAS, not just high ROAS at low spend.",
    "attribution": "Attribution determines which touchpoint gets credit for a conversion. Last-click (default) favors bottom-funnel channels like search. First-click shows discovery channels. Use multi-touch attribution for a complete picture. Remember: all platforms take full credit, so total conversions across platforms will be inflated!",
    "ga4": "GA4 is event-based, unlike Universal Analytics. Set up key events (formerly called conversions) for your business goals. Use UTM parameters on all marketing links. Link GA4 to Google Ads to import conversions. Use Explorations for custom funnel analysis.",
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setInput("");

    // Simple keyword matching for responses
    setTimeout(() => {
      let response =
        "That's a great question! I recommend checking the relevant lessons in the Learning Paths section. You can also try the Campaign Simulator to test different strategies.";

      const lowerInput = userMessage.toLowerCase();
      for (const [keyword, answer] of Object.entries(predefinedResponses)) {
        if (lowerInput.includes(keyword)) {
          response = answer;
          break;
        }
      }

      // Add some helpful suggestions
      if (lowerInput.includes("help") || lowerInput.includes("stuck")) {
        response =
          "I'm here to help! Here are some quick tips:\n\n1. Review the lesson videos carefully\n2. Take notes on key concepts\n3. Try the quizzes to test your knowledge\n4. Use the Campaign Simulator for practice\n5. Check the bookmarked lessons for important topics\n\nWhat specific topic do you need help with?";
      }

      setMessages((prev) => [...prev, { role: "assistant", content: response }]);
    }, 500);
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              size="lg"
              onClick={() => setIsOpen(true)}
              className="rounded-full w-14 h-14 shadow-lg shadow-primary/20"
            >
              <Bot className="w-6 h-6" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)]"
          >
            <Card className="flex flex-col h-[500px] border-border/40 bg-card shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border/40 bg-gradient-to-r from-primary/10 to-purple-500/10">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold flex items-center gap-1">
                      AI Assistant
                      <Sparkles className="w-3 h-3 text-yellow-500" />
                    </h3>
                    <Badge variant="outline" className="text-xs">
                      Always here to help
                    </Badge>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="rounded-full"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-accent"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Input */}
              <div className="p-4 border-t border-border/40">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask me anything..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSend()}
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSend}
                    disabled={!input.trim()}
                    size="icon"
                    className="rounded-full"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  Try asking about Meta Ads, Google Ads, Pixel, or GA4
                </p>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
