import React, { createContext, useContext, useState, useEffect } from 'react';

interface UserProgress {
  completedLessons: string[];
  quizScores: Record<string, number>;
  bookmarks: string[];
  notes: Record<string, string>;
  streak: number;
  lastActive: string;
  score: number;
}

interface UserProgressContextType {
  progress: UserProgress;
  completeLesson: (lessonId: string) => void;
  saveQuizScore: (moduleId: string, score: number) => void;
  toggleBookmark: (lessonId: string) => void;
  saveNote: (lessonId: string, note: string) => void;
  getNote: (lessonId: string) => string;
  isBookmarked: (lessonId: string) => boolean;
  isCompleted: (lessonId: string) => boolean;
}

const UserProgressContext = createContext<UserProgressContextType | undefined>(undefined);

const defaultProgress: UserProgress = {
  completedLessons: [],
  quizScores: {},
  bookmarks: [],
  notes: {},
  streak: 0,
  lastActive: new Date().toISOString(),
  score: 0,
};

export function UserProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('adpulse-progress');
    return saved ? JSON.parse(saved) : defaultProgress;
  });

  useEffect(() => {
    localStorage.setItem('adpulse-progress', JSON.stringify(progress));
  }, [progress]);

  const completeLesson = (lessonId: string) => {
    setProgress((prev) => {
      if (prev.completedLessons.includes(lessonId)) return prev;
      
      const today = new Date().toISOString().split('T')[0];
      const lastActive = new Date(prev.lastActive).toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      
      let newStreak = prev.streak;
      if (lastActive === yesterday) {
        newStreak += 1;
      } else if (lastActive !== today) {
        newStreak = 1;
      }
      
      return {
        ...prev,
        completedLessons: [...prev.completedLessons, lessonId],
        score: prev.score + 100,
        streak: newStreak,
        lastActive: new Date().toISOString(),
      };
    });
  };

  const saveQuizScore = (moduleId: string, score: number) => {
    setProgress((prev) => ({
      ...prev,
      quizScores: { ...prev.quizScores, [moduleId]: score },
      score: prev.score + score * 10,
    }));
  };

  const toggleBookmark = (lessonId: string) => {
    setProgress((prev) => ({
      ...prev,
      bookmarks: prev.bookmarks.includes(lessonId)
        ? prev.bookmarks.filter((id) => id !== lessonId)
        : [...prev.bookmarks, lessonId],
    }));
  };

  const saveNote = (lessonId: string, note: string) => {
    setProgress((prev) => ({
      ...prev,
      notes: { ...prev.notes, [lessonId]: note },
    }));
  };

  const getNote = (lessonId: string) => progress.notes[lessonId] || '';
  const isBookmarked = (lessonId: string) => progress.bookmarks.includes(lessonId);
  const isCompleted = (lessonId: string) => progress.completedLessons.includes(lessonId);

  return (
    <UserProgressContext.Provider
      value={{
        progress,
        completeLesson,
        saveQuizScore,
        toggleBookmark,
        saveNote,
        getNote,
        isBookmarked,
        isCompleted,
      }}
    >
      {children}
    </UserProgressContext.Provider>
  );
}

export function useUserProgress() {
  const context = useContext(UserProgressContext);
  if (!context) {
    throw new Error('useUserProgress must be used within UserProgressProvider');
  }
  return context;
}
