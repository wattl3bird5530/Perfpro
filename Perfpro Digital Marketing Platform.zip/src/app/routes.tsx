import { createBrowserRouter } from "react-router";
import { RootLayout } from "./layouts/RootLayout";
import { Dashboard } from "./pages/Dashboard";
import { LearningPaths } from "./pages/LearningPaths";
import { LessonDetail } from "./pages/LessonDetail";
import { QuizPage } from "./pages/QuizPage";
import { Leaderboard } from "./pages/Leaderboard";
import { Profile } from "./pages/Profile";
import { CampaignSimulator } from "./pages/CampaignSimulator";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "learning-paths", Component: LearningPaths },
      { path: "lesson/:moduleId/:lessonId", Component: LessonDetail },
      { path: "quiz/:moduleId", Component: QuizPage },
      { path: "leaderboard", Component: Leaderboard },
      { path: "profile", Component: Profile },
      { path: "simulator", Component: CampaignSimulator },
      { path: "*", Component: NotFound },
    ],
  },
]);
