
  # Perfpro Digital Marketing Platform

  This is a code bundle for Perfpro Digital Marketing Platform. The original project is available at https://www.figma.com/design/UGs9PHsle9xTW48yE4pZDY/Perfpro-Digital-Marketing-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  